module.exports = {
    "a million dollars": "Do you really think he has that kind of money?",
    "a surprise": "You're daddy said to look under your bed for a surprise.",
    "a hug": "Daddy said he would lvoe to give you a hug, but you have to go to him first.",
    "candy": "Do you want your teeth to rot? Daddy said no.",
    "something special": "You're daddy said sure - something special is having him as a father."
};
