module.exports = {
    "no": "I hope you enjoyed talking with me. Goodbye.",
    "no thanks": "You are polite. Goodbye.",
    "no thank you": "You are really polite. Enjoy the rest of your day.",
    "nothing": "Bye.",
    "nope": "Bye.",
    "not now": "Maybe later?",
    "stop": "No, you stop. Bye."
};